import { useNavigate } from "react-router-dom";

import Navbar from "../components/layout/Navbar";
import Hero from "../components/hero/Hero";
import Features from "../components/features/Features";
import Footer from "../components/layout/Footer";

import { useUpload } from "../hooks/useUpload";

const LandingPage = () => {
  const navigate = useNavigate();

  const { upload, loading } = useUpload();

  const handleUpload = async (file: File) => {
    const response = await upload(file);

    if (!response) return;

    console.log(response);

    navigate("/dashboard");
  };

  return (
    <>
      <Navbar />

      <main className="flex-grow w-full max-w-[1440px] mx-auto px-margin-mobile md:px-margin-desktop flex flex-col gap-section-gap pb-section-gap pt-16">

        <Hero
          onFileSelected={handleUpload}
          loading={loading}
        />

        <Features />

      </main>

      <Footer />
    </>
  );
};

export default LandingPage;