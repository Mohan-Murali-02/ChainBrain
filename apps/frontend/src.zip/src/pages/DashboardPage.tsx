import DashboardLayout from "../components/dashboard/DashboardLayout";

import DashboardHero from "../components/dashboard/overview/DashboardHero";

import AISummary from "../components/dashboard/ai/AISummary";

const DashboardPage = () => {
  return (
    <DashboardLayout>

      <DashboardHero />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

        <AISummary />

      </div>

    </DashboardLayout>
  );
};

export default DashboardPage;