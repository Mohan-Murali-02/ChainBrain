const Footer = () => {
  return (
    <footer className="bg-surface-bright border-t border-outline-variant/20 mt-auto">
      <div className="max-w-[1440px] mx-auto px-margin-desktop py-section-gap flex flex-col md:flex-row justify-between items-center gap-8">

        <div>
          <h2 className="font-headline-md text-headline-md font-bold text-primary">
            ChainBrain
          </h2>
        </div>

        <div className="flex flex-wrap justify-center gap-6 font-body-md">

          <a href="#">Privacy Policy</a>

          <a href="#">Terms of Service</a>

          <a href="#">Security Whitepaper</a>

          <a href="#">Contact Support</a>

        </div>

        <p>
          © 2024 ChainBrain AI Security
        </p>

      </div>
    </footer>
  );
};

export default Footer;