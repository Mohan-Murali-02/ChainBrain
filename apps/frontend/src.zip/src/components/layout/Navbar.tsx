const Navbar = () => {
  return (
    <nav className="bg-surface/80 backdrop-blur-xl border border-on-primary-fixed-variant/10 shadow-sm shadow-[0_20px_40px_rgba(15,23,42,0.05)] rounded-full mt-6 mx-auto w-[90%] max-w-[1440px] sticky top-0 z-50 transition-transform duration-200">
      <div className="flex justify-between items-center px-8 py-3">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <img
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuBzBxmxC2zdL6nU8yJqXLDzFXSZHFJVKN5SUJfFeOGZaXtD9YznWTpqGkg-aoga8K7bfMAW0EpjtZmIOHxldyX52gUaTWoOJ5JJJiMVR21dK00QBojXPP2C7LehxMJO-5YrjQGyZtjJVYg7jZoBwiRQs7FJRGARrLv-qU47scyS_eeMQ8Rna2UW6IYP6ppAG2tubQTyxqRcg0Swa94OBGn8G0g3XmRcx1Ki6IGujHu2YjvP0w2CoVm_"
            alt="ChainBrain Logo"
            className="h-8 w-8 object-contain"
          />

          <span className="font-headline-md text-headline-md font-bold text-on-surface">
            ChainBrain
          </span>
        </div>

        {/* Navigation Links */}
        <div className="hidden md:flex items-center gap-8 font-label-md text-label-md">
          <a
            href="#"
            className="text-secondary font-bold border-b-2 border-secondary pb-1 hover:text-secondary-container transition-colors duration-200"
          >
            Platform
          </a>

          <a
            href="#"
            className="text-on-surface-variant hover:text-secondary-container transition-colors duration-200"
          >
            Features
          </a>

          <a
            href="#"
            className="text-on-surface-variant hover:text-secondary-container transition-colors duration-200"
          >
            Security
          </a>

          <a
            href="#"
            className="text-on-surface-variant hover:text-secondary-container transition-colors duration-200"
          >
            Pricing
          </a>
        </div>

        {/* Right Side Buttons */}
        <div className="flex items-center gap-4">
          <button className="hidden md:block text-on-surface-variant font-label-md hover:text-secondary transition-colors">
            Sign In
          </button>

          <button className="bg-[#0F172A] hover:bg-[#3B82F6] text-white px-6 py-2 rounded-full font-label-md transition-colors duration-200">
            Get Started
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;