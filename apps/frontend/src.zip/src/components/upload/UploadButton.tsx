import { useRef } from "react";

interface UploadButtonProps {
  onFileSelected: (file: File) => void;
  loading?: boolean;
}

const UploadButton = ({
  onFileSelected,
  loading = false,
}: UploadButtonProps) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleClick = () => {
    inputRef.current?.click();
  };

  const handleFileChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];

    if (!file) return;

    if (!file.name.endsWith(".zip")) {
      alert("Please select a ZIP file.");
      return;
    }

    onFileSelected(file);
  };

  return (
    <>
      <input
        ref={inputRef}
        type="file"
        accept=".zip"
        hidden
        onChange={handleFileChange}
      />

      <button
        onClick={handleClick}
        disabled={loading}
        className="bg-[#0F172A] hover:bg-[#3B82F6] text-white px-8 py-4 rounded-full font-label-md text-label-md transition-colors duration-200 flex items-center gap-2 disabled:opacity-60"
      >
        <span
          className="material-symbols-outlined"
          style={{ fontVariationSettings: "'FILL' 1" }}
        >
          upload_file
        </span>

        {loading ? "Uploading..." : "Analyze Project"}
      </button>
    </>
  );
};

export default UploadButton;