import { Bell } from "lucide-react";

const DashboardNavbar = () => {
  return (
    <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6 mb-8">
      <div className="glass-card rounded-[2.5rem] px-8 py-4 flex items-center justify-between">

        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-50 rounded-full flex items-center justify-center border border-blue-100">
            <svg
              className="w-5 h-5 text-blue-600"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A13.916 13.916 0 008 11a4 4 0 118 0c0 1.017-.07 2.019-.203 3m-2.118 6.844A21.88 21.88 0 0015.171 17m3.839 1.132c.645-2.266.99-4.659.99-7.132A8 8 0 008 4.07M3 15.364c.64-1.319 1-2.8 1-4.364 0-1.457.39-2.823 1.07-4"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
              />
            </svg>
          </div>

          <span className="font-bold text-xl tracking-tight">
            ChainBrain
          </span>
        </div>

        {/* Navigation */}

        <div className="hidden md:flex space-x-8">
          <button className="text-primary font-semibold border-b-2 border-blue-500 pb-1">
            Dashboard
          </button>

          <button className="text-secondary hover:text-primary transition-colors font-medium">
            Scans
          </button>

          <button className="text-secondary hover:text-primary transition-colors font-medium">
            AI Assistant
          </button>

          <button className="text-secondary hover:text-primary transition-colors font-medium">
            Settings
          </button>
        </div>

        {/* Right Side */}

        <div className="flex items-center gap-4">
          <button className="text-secondary hover:text-primary transition-colors">
            <Bell size={20} />
          </button>

          <div className="w-10 h-10 rounded-full bg-slate-200 border-2 border-white shadow-sm flex items-center justify-center font-semibold">
            AK
          </div>
        </div>
      </div>
    </nav>
  );
};

export default DashboardNavbar;