import type { ReactNode } from "react";
import DashboardNavbar from "./DashboardNavbar";

interface DashboardLayoutProps {
  children: ReactNode;
}

const DashboardLayout = ({ children }: DashboardLayoutProps) => {
  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />

      <main className="max-w-[1440px] mx-auto px-margin-mobile md:px-margin-desktop py-section-gap">
        {children}
      </main>
    </div>
  );
};

export default DashboardLayout;