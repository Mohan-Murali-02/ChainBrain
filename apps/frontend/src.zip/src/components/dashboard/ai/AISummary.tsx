import { FlaskConical } from "lucide-react";
import { useScanStore } from "../../../store/useScanStore";

const AISummary = () => {
  const aiReport = useScanStore(
    (state) => state.scanResult?.aiReport
  );

  if (!aiReport) return null;

  return (
    <section className="lg:col-span-2 glass-card rounded-[2.5rem] p-8 md:p-10 flex flex-col justify-between">

      <div>

        <div className="flex items-center gap-3 mb-6">

          <div className="w-10 h-10 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 border border-indigo-100">

            <FlaskConical className="w-5 h-5" />

          </div>

          <h2 className="text-2xl font-bold tracking-tight">
            AI Security Summary
          </h2>

        </div>

        <p className="text-secondary text-lg leading-relaxed whitespace-pre-line">

          {aiReport}

        </p>

      </div>

      <div className="mt-10">

        <button className="px-6 py-3 bg-white border border-gray-200 rounded-full font-semibold text-sm hover:bg-gray-50 transition shadow-sm flex items-center gap-2">

          View Full Report

          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              d="M14 5l7 7m0 0l-7 7m7-7H3"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
            />
          </svg>

        </button>

      </div>

    </section>
  );
};

export default AISummary;