import {
  Package,
  Shield,
  ShieldCheck,
  TriangleAlert,
} from "lucide-react";

import MetricCard from "./MetricCard";

import { useScanStore } from "../../../store/useScanStore";

const MetricsGrid = () => {
  const summary = useScanStore(
    (state) => state.scanResult?.scanResults.summary
  );

  if (!summary) return null;

  const riskColor =
    summary.riskLevel === "LOW"
      ? "text-green-600"
      : summary.riskLevel === "MEDIUM"
      ? "text-yellow-600"
      : summary.riskLevel === "HIGH"
      ? "text-orange-600"
      : "text-red-600";

  const riskIcon =
    summary.riskLevel === "LOW"
      ? "bg-green-50 text-green-600 border-green-100"
      : summary.riskLevel === "MEDIUM"
      ? "bg-yellow-50 text-yellow-600 border-yellow-100"
      : summary.riskLevel === "HIGH"
      ? "bg-orange-50 text-orange-600 border-orange-100"
      : "bg-red-50 text-red-600 border-red-100";

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">

      <MetricCard
        title="Security Score"
        value={summary.riskScore}
        suffix="/100"
        icon={
          <ShieldCheck
            className="w-6 h-6"
          />
        }
        iconContainerClassName="bg-blue-50 text-blue-600 border-blue-100"
      />

      <MetricCard
        title="Risk Level"
        value={summary.riskLevel}
        valueClassName={`text-2xl ${riskColor}`}
        icon={
          <Shield
            className="w-6 h-6"
          />
        }
        iconContainerClassName={riskIcon}
      />

      <MetricCard
        title="Total Packages"
        value={summary.totalPackages}
        icon={
          <Package
            className="w-6 h-6"
          />
        }
        iconContainerClassName="bg-slate-50 text-slate-600 border-slate-200"
      />

      <MetricCard
        title="Vulnerable"
        value={summary.vulnerablePackages}
        valueClassName="text-amber-600"
        icon={
          <TriangleAlert
            className="w-6 h-6"
          />
        }
        iconContainerClassName="bg-amber-50 text-amber-600 border-amber-100"
      />

    </div>
  );
};

export default MetricsGrid;