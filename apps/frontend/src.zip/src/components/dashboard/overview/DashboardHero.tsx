import { Clock3, Download, RefreshCw } from "lucide-react";
import { useScanStore } from "../../../store/useScanStore";
import MetricsGrid from "./MetricsGrid";

const DashboardHero = () => {
  const scanResult = useScanStore((state) => state.scanResult);

  if (!scanResult) {
    return (
      <section className="glass-card rounded-[2.5rem] p-10 md:p-14">
        <h2 className="text-3xl font-bold">
          No Scan Available
        </h2>

        <p className="mt-4 text-secondary">
          Upload a project from the landing page.
        </p>
      </section>
    );
  }

  const project = scanResult.projects[0];

  return (
    <section className="glass-card rounded-[2.5rem] p-10 md:p-14 relative overflow-hidden">

      {/* Background Glow */}

      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-blue-50 rounded-full blur-[100px] opacity-60 pointer-events-none -z-10" />

      <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12 gap-6">

        <div>

          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-3">
            Project: {project.name}
          </h1>

          <div className="flex items-center gap-4 text-sm font-medium text-secondary">

            <span className="flex items-center gap-1.5 bg-green-50 text-green-700 px-3 py-1 rounded-full border border-green-100">

              <span className="w-2 h-2 rounded-full bg-green-500" />

              Healthy

            </span>

            <span className="flex items-center gap-1.5">

              <Clock3 size={16} />

              Last scan: Just now

            </span>

          </div>

        </div>

        <div className="flex gap-3">

          <button className="px-6 py-3 bg-white border border-gray-200 rounded-full font-semibold text-sm hover:bg-gray-50 transition shadow-sm flex items-center gap-2">

            <Download size={16} />

            Export

          </button>

          <button className="px-6 py-3 bg-primary text-white rounded-full font-semibold text-sm hover:opacity-90 transition shadow-lg flex items-center gap-2">

            <RefreshCw size={16} />

            Rescan

          </button>

        </div>

      </div>

      <MetricsGrid />

    </section>
  );
};

export default DashboardHero;