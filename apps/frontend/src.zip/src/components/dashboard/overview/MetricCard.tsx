import type { ReactNode } from "react";

interface MetricCardProps {
  title: string;
  value: string | number;
  suffix?: string;
  valueClassName?: string;

  icon: ReactNode;

  iconContainerClassName: string;

  cardClassName?: string;
}

const MetricCard = ({
  title,
  value,
  suffix,
  valueClassName = "",
  icon,
  iconContainerClassName,
  cardClassName = "",
}: MetricCardProps) => {
  return (
    <div
      className={`bg-white/60 rounded-3xl p-6 border border-white/50 shadow-sm flex items-center justify-between ${cardClassName}`}
    >
      <div>
        <p className="text-sm font-medium text-secondary mb-1">
          {title}
        </p>

        <p className={`text-3xl font-bold ${valueClassName}`}>
          {value}

          {suffix && (
            <span className="text-lg text-secondary font-medium">
              {suffix}
            </span>
          )}
        </p>
      </div>

      <div
        className={`w-14 h-14 rounded-full flex items-center justify-center border ${iconContainerClassName}`}
      >
        {icon}
      </div>
    </div>
  );
};

export default MetricCard;