import UploadButton from "../upload/UploadButton";

interface HeroButtonsProps {
  onFileSelected: (file: File) => void;
  loading: boolean;
}

const HeroButtons = ({
  onFileSelected,
  loading,
}: HeroButtonsProps) => {
  return (
    <div className="flex flex-col sm:flex-row gap-4 mt-4">
      <UploadButton
        onFileSelected={onFileSelected}
        loading={loading}
      />

      <button className="glass-panel hover:bg-surface-variant px-8 py-4 rounded-full font-label-md text-label-md text-primary transition-colors flex items-center gap-2">
        <span className="material-symbols-outlined">
          play_circle
        </span>

        Watch Demo
      </button>
    </div>
  );
};

export default HeroButtons;