import HeroBackground from "./HeroBackground";
import HeroButtons from "./HeroButtons";

interface HeroProps {
  onFileSelected: (file: File) => void;
  loading: boolean;
}

const Hero = ({
  onFileSelected,
  loading,
}: HeroProps) => {
  return (
    <section className="relative w-full rounded-4xl overflow-hidden glass-panel ambient-shadow min-h-[600px] flex items-center justify-center p-8 hero-gradient">

      <HeroBackground />

      <div className="relative z-10 max-w-4xl mx-auto text-center flex flex-col items-center gap-8">

        <h1 className="font-display-lg text-display-lg text-primary">
          Understand your project's security before attackers do.
        </h1>

        <p className="font-body-lg text-body-lg text-on-surface-variant max-w-3xl">
          Upload your project ZIP and let AI inspect every dependency,
          detect vulnerabilities, calculate risk scores,
          and generate intelligent security recommendations
          in seconds.
        </p>

        <HeroButtons
          onFileSelected={onFileSelected}
          loading={loading}
        />

      </div>
    </section>
  );
};

export default Hero;