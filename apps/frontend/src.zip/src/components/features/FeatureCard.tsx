interface FeatureCardProps {
  icon: string;
  title: string;
  description: string;
  iconBg: string;
  iconColor: string;
}

const FeatureCard = ({
  icon,
  title,
  description,
  iconBg,
  iconColor,
}: FeatureCardProps) => {
  return (
    <div className="glass-panel p-6 rounded-3xl ai-glow flex flex-col gap-4">
      <div
        className={`w-12 h-12 rounded-full flex items-center justify-center ${iconBg} ${iconColor}`}
      >
        <span className="material-symbols-outlined text-2xl">
          {icon}
        </span>
      </div>

      <h3 className="font-headline-md text-headline-md text-primary">
        {title}
      </h3>

      <p className="font-body-md text-body-md text-on-surface-variant">
        {description}
      </p>
    </div>
  );
};

export default FeatureCard;