export interface Vulnerability {
  // Empty for now.
  // Future:
  // id
  // cve
  // severity
  // description
  // fixVersion
}

export interface PackageScan {
  package: string;
  version: string;
  vulnerabilities: Vulnerability[];
}

export interface ScanSummary {
  totalPackages: number;
  vulnerablePackages: number;
  totalVulnerabilities: number;
  riskScore: number;
  riskLevel: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
}

export interface ScanResults {
  summary: ScanSummary;
  results: PackageScan[];
}

export interface Project {
  path: string;
  name?: string;
  version?: string;

  dependencies: Record<string, string>;

  devDependencies: Record<string, string>;
}

export interface UploadResponse {
  status: string;

  extractPath: string;

  projects: Project[];

  scanResults: ScanResults;

  aiReport: string;
}